import * as React from "react";
import { PropertyControls, ControlType, RenderTarget } from "framer";

interface Props {
  width: number;
  height: number;
  src: string;
  poster: string;
  autoplay: boolean;
  loop: boolean;
  muted: boolean;
  controls: boolean;
}

export class VideoPlayer extends React.Component<Props> {
  static defaultProps = {
    width: 320,
    height: 180,
    src: "https://www.krijnrijshouwer.com/file/example.mp4",
    poster: "https://www.krijnrijshouwer.com/file/example.png",
    autoplay: true,
    loop: true,
    muted: true,
    controls: true
  };

  static propertyControls: PropertyControls<Props> = {
    src: { type: ControlType.String, title: "Source" },
    poster: { type: ControlType.String, title: "Poster" },
    autoplay: { type: ControlType.Boolean, title: "Play" },
    loop: { type: ControlType.Boolean, title: "Loop" },
    muted: { type: ControlType.Boolean, title: "Muted" },
    controls: { type: ControlType.Boolean, title: "Controls" }
  };

  render() {
    let {
      width,
      height,
      src,
      poster,
      autoplay,
      loop,
      muted,
      controls
    } = this.props;

    if (RenderTarget.current() != RenderTarget.preview) {
      controls = false;
      muted = true;
    }

    return (
      <div
        style={{
          width: width,
          height: height,
          overflow: "hidden",
          backgroundColor: "#000",
          color: "#333",
          fontSize: "14px"
        }}
      >
        <video
          poster={poster}
          key={`#${autoplay}`}
          autoPlay={autoplay}
          loop={loop}
          muted={muted}
          controls={controls}
          preload="auto"
          playsInline
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "50% 50%"
          }}
          src={src}
        />
        Your browser does not support HTML5 video.
      </div>
    );
  }
}
